# AsyncServerDevelopment
A repository to work on Async Server Development (with Node JS) course, HIT 2021 Summer.

# Video
Click on the image below in order to view it on YouTube  
[![Expense Management Project (ExpressJS, React and MongoDB)](https://img.youtube.com/vi/7pn2J7KNdqw/0.jpg)](https://www.youtube.com/watch?v=7pn2J7KNdqw "Expense Management Project (ExpressJS, React and MongoDB)")
