import React from "react";

const Options = (props)=>{

    return(
        <option val={props.dateOption}>{props.dateOption}</option>
    );
}

export default Options;
